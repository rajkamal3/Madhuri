package org.capgemini.service;

import java.sql.Date;
import java.util.List;







import org.capgemini.DAO.ItruckbookingDAO;
import org.capgemini.DAO.TruckbookingDAO;
import org.capgemini.com.TruckBean;
import org.capgemini.exception.TruckbookingException;



public class TruckbookingserviceImpl implements ItruckbookingService {
ItruckbookingDAO truckDao=new TruckbookingDAO();
	@Override
	public List<TruckBean> getTruckDetails() throws TruckbookingException {
		
		List<TruckBean> truckDetails= truckDao.getTruckDetails();
		return truckDetails;
	}
	@Override
	public Integer addTruckDetails(TruckBean truckbean)
			throws TruckbookingException {
		
		return truckDao.addTruckDetails(truckbean);
	}
	@Override
	public Integer UpdateTruckDetails(int truckId, String trucktype,
			String origin, String destination, Double charges, int availablenos)
			throws TruckbookingException {
		
		return truckDao.UpdateTruckDetails( truckId,trucktype,
				 origin,destination,charges,availablenos);
	}
	@Override
	public List<TruckBean> getAllTruckDetailsbyId(int truckId)
			throws TruckbookingException {
		
		return truckDao.getAllTruckDetailsbyId(truckId);
	}
	@Override
	public List<TruckBean> getAllDetailssearchtruckID(int truckid)
			throws TruckbookingException {
		// TODO Auto-generated method stub
		return truckDao.getAllDetailssearchtruckID(truckid);
	

}
	@Override
	public String deleteMobile(int truckid) throws TruckbookingException {
		return  truckDao.deleteMobile(truckid);
		
	}
	@Override
	public Long getBookingId(String custId, Long phnnumber, Integer noOfTrucks,
			Integer truckId, Date hdate) throws TruckbookingException {
        truckDao.updateQuantity(noOfTrucks,truckId);
		
		return truckDao.getBookingId(custId, phnnumber, noOfTrucks,truckId, hdate);
		
	}
}
