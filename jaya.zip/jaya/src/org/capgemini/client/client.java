package org.capgemini.client;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.capgemini.DAO.ItruckbookingDAO;
import org.capgemini.DAO.TruckbookingDAO;
import org.capgemini.com.TruckBean;



import org.capgemini.exception.TruckbookingException;
import org.capgemini.service.ItruckbookingService;
import org.capgemini.service.TruckbookingserviceImpl;
import org.capgemini.service.Validator;





public class client {
	public static Scanner scanner=new Scanner(System.in);
	private static ItruckbookingService truckservice=new TruckbookingserviceImpl();
	private static ItruckbookingDAO truckDao=new TruckbookingDAO();
	static TruckBean truckBean=new TruckBean();
	static Validator validator=new Validator();
public static void main(String[]args) throws TruckbookingException, ParseException{
	while(true){

		// show menu
		System.out.println();
		System.out.println();
		System.out.println("  Transport truck Booking System  ");
		System.out.println("_______________________________\n");


		System.out.println("1.Display Trucks");
		System.out.println("2.add truck details");
		System.out.println("3.update truck details");
		System.out.println("4.search truck");
		System.out.println("5.delete truck");
		System.out.println("6.Exit");
		System.out.println("________________________________");
		System.out.println("Select an option:");
		// accept option

		Integer option = scanner.nextInt();
		
		switch (option) {
		
		
		case 1:System.out.println("Enter customer Id:");
		boolean status1=true;
		String custId=null;
		while(status1){
		custId = scanner.next();
   if(validator.isValidCustomerId(custId)){
	   status1=false;
		}else{
			System.out.println("enter valid id");
		}
		}
		System.out.println("Types of Trucks Available: ");
		List<TruckBean> truckDetails=truckservice.getTruckDetails();
		Iterator<TruckBean> iterator= truckDetails.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		} 
		//Long truckId= orderService.placeOrder(customerId, totalPrice,quantity);
		System.out.println("Enter the truckId from above available truck details");
		Integer truckId = scanner.nextInt();
		
								
		System.out.println("Enter the number of trucks to be booked");
		Integer noOfTrucks = scanner.nextInt();
		List<TruckBean> trucksAvail = truckservice.getAllTruckDetailsbyId(truckId);
		
			System.out.println("Enter customer mobile number");
			Long phnnumber = scanner.nextLong();
				System.out.println("Enter the date of transportation");
				String date = scanner.next();
				DateFormat dateformat = new SimpleDateFormat("dd/MM/YYYY");
				java.util.Date udate = dateformat.parse(date);
				java.sql.Date hdate = new java.sql.Date(udate.getTime());
				
				Long bookingId = truckservice.getBookingId(custId, phnnumber, noOfTrucks,truckId,hdate);
				System.out.println(" Booking Successful.......\n Your booking id::"+bookingId);
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		
			/*System.out.println("Enter customer Id:");
		       String custId = scanner.next();
		       System.out.println("Types of Trucks Available: "); 
			   List<TruckBean> truckList=getTruckDetails();
		       showtruck(truckList);*/
		break;
		case 2:System.out.println("Enter truckId: ");
              truckId=scanner.nextInt();
             scanner.nextLine();
             System.out.println("Enter trucktype: ");
             String trucktype=scanner.nextLine();
             System.out.println("Enter origin:");
             String origin=scanner.nextLine();
             System.out.println("Enter destination: ");
             String destination=scanner.nextLine();
             System.out.println("Enter charges: ");
             double charges=scanner.nextDouble();
             System.out.println("Enter availablenos ");
             int availablenos=scanner.nextInt();
             truckBean.setTruckId(truckId);
             truckBean.setTrucktype(trucktype);
             truckBean.setOrigin(origin);
             truckBean.setDestination(destination);
             truckBean.setCharges(charges);
             truckBean.setAvailablenos(availablenos);
             int n=truckservice.addTruckDetails(truckBean);
				if(n!=0) {
					System.out.println("Succesfully inserted");
				}
				break;
		case 3:System.out.println("Enter your truck Id: ");
		int truckid=scanner.nextInt();
		System.out.println("Employee Id:"+truckid);
		List<TruckBean> empBean2;
		empBean2=truckservice.getAllTruckDetailsbyId(truckid);
		Iterator<TruckBean> iterator1=empBean2.iterator();
		while(iterator1.hasNext()){
			System.out.println(iterator1.next());
		}
		System.out.println("\n");
		System.out.println("Modify your Details here...");
		System.out.println("\n");
		System.out.println("truckid: "+truckid);
		System.out.println("Enter truckType ");
		scanner.nextLine();
		String truckType=scanner.nextLine();
		
		System.out.println("New truckType:"+truckType);
		System.out.println("Enter Origin");
		String Origin=scanner.nextLine();
		System.out.println("New Origin:"+Origin);
		System.out.println("Enter Destination");
		String Destination=scanner.nextLine();
		System.out.println("New Origin:"+Destination);
		System.out.println("Enter Charges");
		double Charges=scanner.nextDouble();
		System.out.println("New Charges:"+Charges);
		System.out.println("Enter AvailableNos");
		int AvailableNos=scanner.nextInt();
		System.out.println("New AvailableNos:"+AvailableNos);
		Integer Update=truckservice.UpdateTruckDetails(truckid,truckType,Origin,Destination,Charges,AvailableNos);
		if(Update>0){
			System.out.println("Updated Successfully...");
		}else{
			System.out.println("Failed to Update...");
		}
		break;
		case 4:System.out.println("Enter the option to Search: \n 1.Employee Id ");
		int options=scanner.nextInt();
		scanner.nextLine();
		System.out.println("Enter employeeID");
			int truckid1=scanner.nextInt();
			List<TruckBean> truckBeans= truckservice.getAllDetailssearchtruckID(truckid1);
			Iterator<TruckBean> iterator3=truckBeans.iterator();
			while(iterator3.hasNext()){
				System.out.println(iterator3.next());
			}
			break;
			case 5:System.out.println("enter truckId:");
			int truckid2=scanner.nextInt();
			String status=deletetruck(truckid2);
			System.out.println(status); 
		case 6:System.exit(0);
			break;
		default:System.out.println("enter valid options");
		break;
		}
}

}

private static String deletetruck(int truckid2) {
	try {
		String status=truckservice.deleteMobile(truckid2);
		return status;
	} catch (TruckbookingException e) {
		
		//System.out.println(e.getMessage());
	}
	return null;
}

private static void showtruck(List<TruckBean> truckList) {
	if(truckList!=null){
		Iterator<TruckBean> iterator=truckList.iterator();
		while(iterator.hasNext()){
			System.out.println(iterator.next());
		}
	}else{
		System.out.println("No data found");
	}

}
private static List<TruckBean> getTruckDetails() throws TruckbookingException {
	List<TruckBean> employeeList=truckDao.getTruckDetails();
	return employeeList;
	
}
}