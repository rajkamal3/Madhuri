package org.capgemini.exception;

public class TruckbookingException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String message;

	public TruckbookingException(String message) {
		super();
		this.message = message;
	}


	public void setMessage(String message) {
	
		this.message = message;
	}

	@Override
	public String toString() {
		return "TruckbookingException [message=" + message + "]";
	}
	
	
}
