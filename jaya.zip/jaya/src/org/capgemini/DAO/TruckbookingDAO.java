package org.capgemini.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.capgemini.com.TruckBean;

import org.capgemini.exception.TruckbookingException;
import org.capgemini.utility.DBConnection;



public class TruckbookingDAO implements ItruckbookingDAO {
	static TruckBean truckBean=new TruckBean();
	private static Logger myDAOLogger=Logger.getLogger(TruckbookingDAO.class);
	@Override
	public List<TruckBean> getTruckDetails() throws TruckbookingException {
		int truckcount=0;
		try (
			Connection connection=DBConnection.getConnection();
			Statement statement=connection.createStatement();){
				ResultSet resultSet=statement.executeQuery(" select * from truckdetails");
				List<TruckBean> truckList=new ArrayList<>();
				
			while(resultSet.next()){
				truckcount++;
				TruckBean truckbean=new TruckBean();
				populatetruck(truckbean,resultSet);
				truckList.add(truckbean);
				
			}
			if(truckcount!=0){
				myDAOLogger.info("list displayed");
				return truckList;
			}else{
				return null;
			}
		} catch (SQLException e) {
			myDAOLogger.error(e);
			e.printStackTrace();
		}
		return null;
	}

	private void populatetruck(TruckBean truckbean, ResultSet resultSet) throws SQLException {
		truckbean.setTruckId(resultSet.getInt("truckid"));
		truckbean.setTrucktype(resultSet.getString("truckType"));
		truckbean.setOrigin(resultSet.getString("origin"));
		truckbean.setDestination(resultSet.getString("destination"));
		truckbean.setCharges(resultSet.getDouble("charges"));
		truckbean.setAvailablenos(resultSet.getInt("availableNos"));
		
	}

	@Override
	public Integer addTruckDetails(TruckBean truckbean)
			throws TruckbookingException {
		try (
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement("insert into truckdetails values(?,?,?,?,?,?)");
				){
					preparedStatement.setInt(1,truckbean.getTruckId());
					preparedStatement.setString(2,truckbean.getTrucktype());
					preparedStatement.setString(3,truckbean.getOrigin());
					preparedStatement.setString(4,truckbean.getDestination());
					preparedStatement.setDouble(5,truckbean.getCharges());
					preparedStatement.setInt(6,truckbean.getAvailablenos());
					int n=preparedStatement.executeUpdate();
					
					if(n!=0){
						return n;
					}
		
	}catch(SQLException e){
		myDAOLogger.error(e);
		e.printStackTrace();
	}
		return null;

}

	@Override
	public Integer UpdateTruckDetails(int truckId, String trucktype,
			String origin, String destination, Double charges, int availablenos)
			throws TruckbookingException {
	try {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement
		("update truckdetails set trucktype=?,origin=?,destination=?,charges=?,availablenos=?");
		
		preparedStatement.setString(1,trucktype);
		preparedStatement.setString(2,origin);
		preparedStatement.setString(3,destination);
		preparedStatement.setDouble(4,charges);
		preparedStatement.setInt(5,availablenos);
		int n=preparedStatement.executeUpdate();
		if(n!=0){
			return n;
			
		}
	} catch (SQLException e) {
		myDAOLogger.error(e);
		e.printStackTrace();
	}
		return null;
	}

	@Override
	public List<TruckBean> getAllTruckDetailsbyId(int truckid)
			throws TruckbookingException {
		List<TruckBean> truckBeans=new ArrayList<TruckBean>();
	try {
		Connection connection=DBConnection.getConnection();
		PreparedStatement preparedStatement=connection.prepareStatement("select * from truckdetails where truckid=?");
		preparedStatement.setInt(1,truckid);
		ResultSet resultSet=preparedStatement.executeQuery();
		while(resultSet.next()){
			TruckBean truckbean=new TruckBean();
			truckbean.setTruckId(resultSet.getInt("truckid"));
			truckbean.setTrucktype(resultSet.getString("trucktype"));
			truckbean.setOrigin(resultSet.getString("origin"));
			truckbean.setDestination(resultSet.getString("destination"));
			truckbean.setCharges(resultSet.getDouble("charges"));
			truckbean.setAvailablenos(resultSet.getInt("availablenos"));
			truckBeans.add(truckbean);
			
		}
	} catch (SQLException e) {
		myDAOLogger.error(e);
		e.printStackTrace();
	}
		return truckBeans;
	}

	@Override
	public List<TruckBean> getAllDetailssearchtruckID(int truckid)
			throws TruckbookingException {
		List<TruckBean> truckBeans=new ArrayList<TruckBean>();
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement("select * from truckdetails where truckid=?");
			preparedStatement.setInt(1,truckid);
			ResultSet resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next()){
				TruckBean truckbean=new TruckBean();
				truckbean.setTruckId(resultSet.getInt("truckid"));
				truckbean.setTrucktype(resultSet.getString("trucktype"));
				truckbean.setOrigin(resultSet.getString("origin"));
				truckbean.setDestination(resultSet.getString("destination"));
				truckbean.setCharges(resultSet.getDouble("charges"));
				truckbean.setAvailablenos(resultSet.getInt("availablenos"));
				truckBeans.add(truckbean);
			}
		} catch (SQLException e) {
			myDAOLogger.error(e);
			e.printStackTrace();
		}
		return truckBeans;
	}

	@Override
	public String deleteMobile(int truckid) throws TruckbookingException {
		try {
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=connection.prepareStatement("delete from truckdetails where truckid=?");
			preparedStatement.setInt(1,truckid);
			int n=preparedStatement.executeUpdate();
			if(n>0){
				System.out.println("success"); 
			}else{
				System.out.println("failed");
			}
		} catch (SQLException e) {
			myDAOLogger.error(e);
			e.printStackTrace();
		}
		return null;
		
	}

	@Override
	public Long getBookingId(String custId, Long custMobile,
			Integer noOfTrucks, Integer truckId, Date date)
			throws TruckbookingException {
		try (
			Connection connection=DBConnection.getConnection();
			PreparedStatement preparedStatement=
			connection.prepareStatement("insert into bookingdetails values(booking_id_seq.NEXTVAL,?,?,?,?,?)");
			Statement statement = connection.createStatement();
		){
	preparedStatement.setString(1, custId);
	preparedStatement.setLong(2,custMobile);
	preparedStatement.setInt(3,truckId);
	preparedStatement.setInt(4,noOfTrucks);
	preparedStatement.setDate(5,date);
	int n=preparedStatement.executeUpdate();
	if(n>0){
		ResultSet resultSet=statement.executeQuery("SELECT booking_id_seq.CURRVAL from dual");
		if(resultSet.next()){
			Long BookingId=resultSet.getLong(1);
			return BookingId;
		}
	}
		
		} catch (SQLException e) {
			myDAOLogger.error(e);
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer updateQuantity(Integer noOfTrucks, Integer truckId) {
		try(Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement("UPDATE TruckDetails set availableNos=availableNos-? where truckId =?");

				){
			preparedStatement.setInt(1,noOfTrucks );
			preparedStatement.setInt(2,truckId);

			int n=preparedStatement.executeUpdate();
			if(n>0){
				return n;
			}
		}catch(SQLException e){
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();

		}catch(Exception e){
			myDAOLogger.error(e.getMessage());
			e.printStackTrace();
		}
		
		return null;
	}
		
	}

	







	