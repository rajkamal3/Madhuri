package org.capgemini.DAO;

import java.sql.Date;
import java.util.List;

import org.capgemini.com.TruckBean;
import org.capgemini.exception.TruckbookingException;

public interface ItruckbookingDAO {
	public List<TruckBean> getTruckDetails() throws TruckbookingException ;
	public Integer addTruckDetails(TruckBean truckbean)throws TruckbookingException;
public abstract Integer UpdateTruckDetails(int truckId, String trucktype, String origin,
		String destination, Double charges, int availablenos)throws TruckbookingException;
public abstract List<TruckBean> getAllTruckDetailsbyId(int truckId) throws TruckbookingException;
public List<TruckBean> getAllDetailssearchtruckID(int truckid) throws TruckbookingException;
public String deleteMobile(int truckid)throws TruckbookingException;
public Long getBookingId(String custId,
		Long custMobile,Integer noOfTrucks,Integer truckId,Date date) throws TruckbookingException;
public Integer updateQuantity(Integer noOfTrucks, Integer truckId);


}
