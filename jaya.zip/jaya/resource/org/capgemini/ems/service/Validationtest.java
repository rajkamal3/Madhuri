package org.capgemini.ems.service;

import static org.junit.Assert.*;

import org.capgemini.service.Validator;
import org.junit.Test;



public class Validationtest {

	/*@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidator() {
		fail("Not yet implemented");
	}

	
	@Test
	public void testIsValidCustomerMobile() {
		fail("Not yet implemented");
	}*/
	
	@Test
	public void testIsValidCustomerId() {
		assertTrue(new Validator().isValidCustomerId("A111111"));
	}


}
